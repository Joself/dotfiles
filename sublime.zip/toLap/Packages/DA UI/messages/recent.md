**1.0.0-beta.1.2**

Currently, Sublime Text custom loader doesn't support nested `.pyc` modules
inside `*.sublime-package` files.

That's why I've forced package to be extracted.

Please re-install the `DA UI` package if you have some errors.

***

Sorry for the inconvenience! 🐛

Have a nice day! ☕
